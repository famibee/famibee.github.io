The themes contained in this folder are to be considered samples only
and are not certified as being ready for production applications.  It is
recommended that you test your UI thoroughly when using these themes to
make sure that everything appears correctly, and you are encouraged to
make changes directly to the theme as necessary.  If you find your
changes would be useful to other users, please contribute them back as
discussed at http://opensource.adobe.com/flex.